
import { FaBuilding, FaCar, FaUserTie, FaEuroSign, FaChartLine, FaInbox } from "react-icons/fa";

const stats = [
  { title: "Toplam Firma", value: 15, icon: <FaBuilding />, color: "bg-blue-500" },
  { title: "Kayıtlı Araçlar", value: 120, icon: <FaCar />, color: "bg-green-500" },
  { title: "Aktif Şoförler", value: 85, icon: <FaUserTie />, color: "bg-yellow-500" },
  { title: "Bugünkü Gelir", value: "3.280 €", icon: <FaEuroSign />, color: "bg-purple-500" },
  { title: "Aylık Kazanç", value: "92.400 €", icon: <FaChartLine />, color: "bg-red-500" },
  { title: "Bekleyen Talepler", value: 7, icon: <FaInbox />, color: "bg-gray-600" },
];

export default function AdminDashboard() {
  return (
    <div className="p-6 grid gap-6 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
      {stats.map((item, idx) => (
        <div key={idx} className={`rounded-xl text-white p-5 shadow-md flex items-center gap-4 ${item.color}`}>
          <div className="text-3xl">{item.icon}</div>
          <div>
            <h3 className="text-lg font-semibold">{item.title}</h3>
            <p className="text-2xl">{item.value}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

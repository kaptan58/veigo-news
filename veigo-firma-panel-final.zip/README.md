# VEIGO Firma Paneli

## Kurulum
```bash
npm install
npm run dev
```
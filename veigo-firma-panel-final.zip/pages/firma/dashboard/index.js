
export default function FirmaDashboard() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Firma Paneli</h1>
      <p>Toplam Şoför: 12</p>
      <p>Toplam Araç: 8</p>
      <p>Bugünkü Kazanç: 325 €</p>
    </div>
  );
}


export async function getServerSideProps(context) {
  const { req, query } = context;
  const submitted = query.submitted;
  const email = query.email;
  const password = query.password;

  if (submitted === 'true') {
    if (email === 'admin@veigo.de' && password === '123456') {
      return {
        redirect: {
          destination: '/dashboard',
          permanent: false,
        },
      };
    } else {
      return {
        props: {
          error: 'Geçersiz giriş!',
        },
      };
    }
  }

  return { props: {} };
}

export default function Login({ error }) {
  return (
    <div className="flex flex-col items-center justify-center h-screen p-4">
      <img src="/logo.png" alt="Logo" className="w-24 mb-4" />
      <h1 className="text-2xl font-bold mb-4">Admin Giriş</h1>
      <form method="get" className="flex flex-col gap-3 w-full max-w-sm">
        <input name="email" type="email" placeholder="E-posta" className="p-2 border rounded" defaultValue="admin@veigo.de" />
        <input name="password" type="password" placeholder="Şifre" className="p-2 border rounded" defaultValue="123456" />
        <input type="hidden" name="submitted" value="true" />
        <button type="submit" className="bg-blue-600 text-white p-2 rounded">Giriş Yap</button>
        {error && <p className="text-red-500">{error}</p>}
      </form>
    </div>
  );
}

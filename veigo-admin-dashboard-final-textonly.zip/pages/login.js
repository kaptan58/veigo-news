
import { useRouter } from 'next/router';
import { useState } from 'react';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    if (email === 'admin@veigo.de' && pass === '123456') {
      router.push('/dashboard');
    } else {
      setError('Geçersiz giriş!');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen p-4">
      <img src="/logo.png" alt="Logo" className="w-24 mb-4" />
      <h1 className="text-2xl font-bold mb-4">Admin Giriş</h1>
      <form onSubmit={handleLogin} className="flex flex-col gap-3 w-full max-w-sm">
        <input type="email" placeholder="E-posta" className="p-2 border rounded" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="Şifre" className="p-2 border rounded" value={pass} onChange={(e) => setPass(e.target.value)} />
        <button type="submit" className="bg-blue-600 text-white p-2 rounded">Giriş Yap</button>
        {error && <p className="text-red-500">{error}</p>}
      </form>
    </div>
  );
}


export default function Dashboard() {
  const stats = [
    { title: "Toplam Firma", value: 15 },
    { title: "Kayıtlı Araçlar", value: 120 },
    { title: "Aktif Şoförler", value: 85 },
    { title: "Bugünkü Gelir", value: "3.280 €" },
    { title: "Aylık Kazanç", value: "92.400 €" },
    { title: "Bekleyen Talepler", value: 7 },
  ];

  return (
    <div className="p-6 grid gap-6 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
      {stats.map((item, i) => (
        <div key={i} className="rounded-xl bg-gray-800 text-white p-5 shadow-md flex flex-col gap-2">
          <h3 className="text-lg font-semibold">{item.title}</h3>
          <p className="text-2xl">{item.value}</p>
        </div>
      ))}
    </div>
  );
}
